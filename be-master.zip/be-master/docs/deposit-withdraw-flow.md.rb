1. Ví Deposit dùng để tạo địa chỉ cho user
2. Ví Hot được dùng để withdraw
3. Ví Fee dùng để chuyển tiền dùng lmà fee cho ví của User
4. Ví Hot, Warm, Cold sẽ nhận tiền khi deposit từ User, thứ tự nhận ưu tiên là Hot => Warm => Cold. Ví Cold không có max
5. Khi nhận deposit từ ERC20, hệ thống sẽ chuyển tiền từ ví Fee vào ví User. Sau đó dùng tiền đó thực hiện việc chuyển tiền về 3 ví withdraw
6. Khi withdraw chuyển sẽ được chuyển từ ví Hot đi