# Getting Bitcoins in Testnet

When system will generate your personal BTC deposit address you may want to deposit some coins to it. Since Peatio uses Bitcoin Testnet by default you can use any existing public faucets to get coins:

* [https://testnet.manu.backend.hamburg/faucet](https://testnet.manu.backend.hamburg/faucet)
* [http://tpfaucet.appspot.com](http://tpfaucet.appspot.com)
* [https://kuttler.eu/en/bitcoin/btc/faucet](https://kuttler.eu/en/bitcoin/btc/faucet)
* [http://bitcoinfaucet.uo1.net](http://bitcoinfaucet.uo1.net)
* [https://testnet.coinfaucet.eu/en](https://testnet.coinfaucet.eu/en)

Open any public faucet in the browser, copy your deposit address and paste it to the field, optionally solve captcha and submit the form. Wait until transaction will receive enough confirmations. Then you will see your balance at «Funds». 
