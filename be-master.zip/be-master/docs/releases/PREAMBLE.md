# Peatio releases

**Peatio respects a modified version of [SemVer](http://semver.org), similar to the Ruby on Rails project.**
