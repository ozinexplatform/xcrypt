# Ethereum node remote
### 1. Sử dụng pem file để remote lên server
  - File `ozinex-eth.pem` ở thư mục `/home/dy/Downloads/ozinex-eth.pem`
  - Set quyền sử dụng file là 600 (ubuntu)
    ```bash
    sudo chmod 600 /home/dy/Downloads/ozinex-eth.pem
    ```
  - Sử dụng lệnh ssh để remote lên server
    ```bash
    ssh -i /home/dy/Downloads/ozinex-eth.pem ubuntu@1.2.3.4
    ```
    Trong đó ubuntu là username của server, 1.2.3.4 là địa chỉip của server
  - Di chuyển đến thư mục chứa `geth`
    ```bash
    cd /home/ubuntu/go-ethereum-1.8.23/build/bin
    ```
  - Truy cập vào ứng dụng geth console
    ```bash
    ./geth attach http://localhost:8545
    ```
  - Cách sử dụng geth console: https://github.com/ethereum/go-ethereum/wiki/Management-APIs