# encoding: UTF-8
# frozen_string_literal: true

module HandleSwapService
  module_function
  Error                  = Class.new(StandardError) # TODO: Rename to Exception.
  ConnectionRefusedError = Class.new(StandardError) # TODO: Remove this.

  def call params, current_user
    @params = params
    @current_user = current_user

    base_user = Member.find_by email: ENV["BASE_SWAP_USER"]
    txto_account_base = base_user.accounts.find_by currency_id: "txt-o"
    txt_account_base = base_user.accounts.find_by currency_id: "txt"
    plus_sub_base_user(txto_account_base, txt_account_base)
    txto_account_user = @current_user.accounts.find_by currency_id: "txt-o"
    txt_account_user = @current_user.accounts.find_by currency_id: "txt"
    plus_sub_user(txto_account_user, txt_account_user)
  end

  def plus_sub_base_user txto_account_base, txt_account_base
    txt_account_base.update! balance: txt_account_base.balance - @params["old_coin_amount"].to_f
    txto_account_base.update! balance: txto_account_base.balance + @params["old_coin_amount"].to_f
  end

  def plus_sub_user txto_account_user, txt_account_user
    txt_account_user.update! balance: txt_account_user.balance + @params["old_coin_amount"].to_f
    txto_account_user.update! balance: txto_account_user.balance - @params["old_coin_amount"].to_f
  end
end
