# encoding: UTF-8
# frozen_string_literal: true

module AdminService
  module News
    class CreateService
      attr_reader :params, :categories, :news, :valid

      def initialize args = {}
        @categories = args[:categories]
        @params     = args[:params]
        @valid      = true
      end

      def perform
        ActiveRecord::Base.transaction do
          @news = ::News.create(params)
          return if @categories.blank?

          @categories.each do |id|
            @news.news_category_mediates.create!(news_category_id: id)
          end
        rescue
          @valid = false
        end
      end
    end
  end
end
