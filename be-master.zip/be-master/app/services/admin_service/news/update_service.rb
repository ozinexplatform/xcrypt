# encoding: UTF-8
# frozen_string_literal: true

module AdminService
  module News
    class UpdateService
      attr_reader :params, :categories, :news, :valid

      def initialize args = {}
        @news       = args[:news]
        @params     = args[:params]
        @categories = (args[:categories].presence || []).map(&:to_i)
        @valid      = true
      end

      def perform
        ActiveRecord::Base.transaction do
          @news.update!(params)

          new_categories.each do |id|
            create_news_category_mediate id
          end

          delete_ids.each do |id|
            delete_news_category_mediate id
          end
        rescue
          @valid = false
        end
      end

      private

      def current_categories
        @current_categories ||= @news.news_category_mediates.pluck :news_category_id
      end

      def delete_ids
        current_categories - categories
      end

      def new_categories
        categories - current_categories
      end

      def delete_news_category_mediate id
        @news.news_category_mediates.find_by(news_category_id: id).destroy
      end

      def create_news_category_mediate id
        @news.news_category_mediates.create!(news_category_id: id)
      end
    end
  end
end
