class BaseMailer < ActionMailer::Base
  default from: ENV["SMTP_USERNAME"]
  add_template_helper(EmailHelper)
end