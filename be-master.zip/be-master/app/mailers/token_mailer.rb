class TokenMailer < BaseMailer

  def send_code(member, otp_code)
    @otp_code = otp_code
    mail(to: member.email, subject: 'Ozinex Two factor') do |format|
      format.text
    end
  end
end