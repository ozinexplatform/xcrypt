class MyMailer < Devise::Mailer
  helper :application # gives access to all helpers defined within `application_helper`.
  helper :email
  include Devise::Controllers::UrlHelpers # Optional. eg. `confirmation_url`
  default template_path: 'devise/mailer' # to make sure that your mailer uses the devise views
  default from: ENV["NO_REPLY_EMAIL"]

  def default_url_options
    {
      :host => host
    }
  end

  def confirmation_instructions(record, token, opts={})
    headers["Custom-header"] = "Bar"
    mail = super
    mail.subject = "[Ozinex] - Please Verify Your Account"
    mail
  end

  def reset_password_instructions(record, token, opts={})
    headers["Custom-header"] = "Bar"
    mail = super
    mail.subject = "[Ozinex] - Please Confirm To Reset Password"
    mail
  end

  private

    def host
      ENV["URL_HOST"]
    end
end