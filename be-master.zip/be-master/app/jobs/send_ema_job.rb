class SendEmaJob < ActiveJob::Base
  queue_as :default

  def perform(mailer, mailer_method, options={})
    mailer.send(mailer_method, options)
  end
end