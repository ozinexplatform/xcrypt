class SendSmsJob < ActiveJob::Base
  queue_as :default

  # Define our Twilio credentials as instance variables for later use
  @@twilio_sid = ENV['TWILIO_ACCOUNT_SID']
  @@twilio_token = ENV['TWILIO_AUTH_TOKEN']
  @@twilio_number = ENV['TWILIO_NUMBER']

  def perform(to, sms_message)
    client = Twilio::REST::Client.new @@twilio_sid, @@twilio_token

    call = client.messages.create(
      from: @@twilio_number,
      to: to,
      body:  sms_message
    )
  end
end