class Members::RegistrationsController < Devise::RegistrationsController
  before_filter :configure_permitted_parameters, only: [:create]

  def create
    if params[:refferal_code].present?
      refferal_member = Member.find_by(sn: params[:refferal_code])
      params_failed   = {
        refferal_code: params[:refferal_code],
        member: params[:member]
      }

      return redirect_to signup_path(params_failed), alert: t('custom_errors.refferal_code_invalid') unless refferal_member
    end

    build_resource(sign_up_params)

    ActiveRecord::Base.transaction do
      resource.save

      next unless refferal_member

      Refferal.create(
        reffered_by: refferal_member.id,
        reffered_user: resource.id,
      )
    end

    yield resource if block_given?

    if resource.persisted?
      if resource.active_for_authentication?
        set_flash_message! :notice, :signed_up
        sign_up(resource_name, resource)
        respond_with resource, location: after_sign_up_path_for(resource)
      else
        set_flash_message! :notice, :"signed_up_but_#{resource.inactive_message}"
        expire_data_after_sign_in!
        respond_with resource, location: after_inactive_sign_up_path_for(resource)
      end
    else
      clean_up_passwords resource
      set_minimum_password_length
      if resource.errors.blank?
        respond_with resource
      else
        flash[:alert] = resource.errors.full_messages.join("<br />").html_safe
        redirect_to signup_path(member: params[:member])
      end
    end
  end

  private
    def after_inactive_sign_up_path_for(resource)
      "/signup"
    end

    def after_sign_up_path_for(resource)
      "/login"
    end

  protected

    def configure_permitted_parameters
      devise_parameter_sanitizer.permit(:sign_up) { |u|
        u.permit(:email, :password, :password_confirmation, profile_attributes: [:first_name, :last_name])
      }
    end

    def load_refferal_member
      @refferal_member = Member.find_by(sn: params[:refferal_code])
    end
end
