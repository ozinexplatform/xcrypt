# encoding: UTF-8
# frozen_string_literal: true

class WelcomeController < BaseTemplateController
  LIMIT_NEWS = 8.freeze

  before_action :load_news, :load_news_with_banner, :load_categories, only: :index

	def index
    @markets = Market.all.enabled
    @top_markets = @markets.sort_by{|market| market.ticker["volume"]}.first(4)
    @btc_markets = @markets.select{|market| market.quote_unit == "btc"}
    @eth_markets = @markets.select{|market| market.quote_unit == "eth"}
    @usdt_markets = @markets.select{|market| market.quote_unit == "usdt"}

    @official_announcements = @news.enable
                                   .joins(news_category_mediates: :news_category)
                                   .where(news_categories: { name: 'Official Announcement' })
                                   .limit(LIMIT_NEWS)
                                   .order('created_at DESC')
    @news_listing           = @news.enable
                                   .joins(news_category_mediates: :news_category)
                                   .where(news_categories: { name: 'New listings' })
                                   .limit(LIMIT_NEWS)
                                   .order('created_at DESC')
    @event                  = @news.enable
                                   .joins(news_category_mediates: :news_category)
                                   .where(news_categories: { name: 'Event' })
                                   .limit(LIMIT_NEWS)
                                   .order('created_at DESC')

    @official_announcement_category = @categories.find_by(name: 'Official Announcement')
    @news_listing_category          = @categories.find_by(name: 'New listings')
    @event_category                 = @categories.find_by(name: 'Event')
	end

  private

  def page_info
    {
      title: "Explore Trading Charts",
      description_1: "Many desktop publishing packages and web page editors now use",
      description_2: "Lorem Ipsum as their default model text"
    }
  end

  def load_news
    @news = News.all
  end

  def load_news_with_banner
    @news_with_banner = @news.enable.show
  end

  def load_categories
    @categories = NewsCategory.all
  end
end
