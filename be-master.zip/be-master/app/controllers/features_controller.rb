class FeaturesController < BaseTemplateController

	def index
		
	end

  private
    def page_info
      {
        title: "Our Features",
        description_1: "Many desktop publishing packages and web page editors now use",
        description_2: "Lorem Ipsum as their default model text"
      }
    end
end
