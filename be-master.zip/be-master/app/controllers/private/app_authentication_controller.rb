module Private
  class AppAuthenticationController < BaseController
    before_action :app_authentication_otp_valid!

    def active
      current_user.app_two_factor.enable!
      current_user.security.update is_two_factor_login: true
      session[:logged_in_2fa] = true
      redirect_to profiles_path, notice: "Successfully"
    end

    def deactive
      current_user.app_two_factor.disable!
      redirect_to :back, notice: "Successfully"
    end
  end
end
