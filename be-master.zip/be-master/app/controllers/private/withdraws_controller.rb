# encoding: UTF-8
# frozen_string_literal: true

module Private
  class WithdrawsController < BaseController
    before_action :check_2fa, only: %i(create)
    # before_action :withdraws_must_be_permitted!
    before_action :withdraw_must_be_match_conditions, only: %i(create)

    def create
      @withdraw = withdraw_class.new(withdraw_params)

      if @withdraw.save
        @withdraw.submit!
        head 204
      else
        render text: @withdraw.errors.full_messages.join(', '), status: 422
      end
    end

    def destroy
      Withdraw.transaction do
        @withdraw = current_user.withdraws.find(params[:id]).lock!
        @withdraw.cancel
        @withdraw.save!
      end
      head 204
    end

  private

    def currency
      @currency ||= Currency.enabled.find(params[:currency])
    end

    def withdraw_class
      "withdraws/#{currency.type}".camelize.constantize
    end

    def withdraw_params
      params.require(:withdraw)
            .permit(:rid, :member_id, :currency_id, :sum)
            .merge(currency_id: currency.id, member_id: current_user.id)
            .permit!
    end

    def check_2fa
      app = current_user.app_two_factor

      return render text: "Please enable two factor!", status: 422 unless app.is_enabled

      return render text: "Please input 2FA code!", status: 422 unless params["withdraw"]["code"]

      check_verify_2fa params["withdraw"]["code"]
    end

    def withdraw_must_be_match_conditions
      # return if ["agvc", "ozi"].exclude?(currency.id)
      return unless current_user.bonus_register_flag
      return render text: "Account must be created over 24 hours", status: 422 if current_user.profile.approved_at.nil? ||
                                                                                  current_user.profile.approved_at + 24.hours > DateTime.now
      account = current_user.accounts.find_by(currency_id: currency.id)
      orders = current_user.orders.where("orders.bid = ? OR orders.ask = ?" , currency.id, currency.id)
                                  .where(state: "done")

      return render text: "You must finish 10 trading transaction of #{currency.id}", status: 422 if orders.length < 10
    end

    def check_verify_2fa params
      activated_two_factor = current_user.app_two_factor
      activated_two_factor.otp = params
      unless activated_two_factor.verify?
        return render text: "2FA code is wrong!", status: 422
      end
    end
  end
end
