module Private
  class SmsAuthenticationController < BaseController
    before_action :sms_authentication_otp_valid!
    before_action :set_sms

    def active
      @sms.enable!
      @sms.country = params[:country]
      @sms.phone_number = params[:phone_number]
      @sms.update_profile
      redirect_to :back, notice: "Successfully"
    end

    def deactive
      @sms.disable!
      @sms.reset_profile
      redirect_to :back, notice: "Successfully"
    end

    private
      def set_sms
        @sms = current_user.sms_two_factor
      end
  end
end
