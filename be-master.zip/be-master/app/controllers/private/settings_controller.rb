# encoding: UTF-8
# frozen_string_literal: true

module Private
  class SettingsController < BaseController
    before_action :checkout_state, only: %i(index)

    def index

    end

    def update
      current_user.profile.update! permit_params.merge(state: "pending")
      redirect_to profiles_path, notice: "Successfully"
    end

    private

    def permit_params
      params.require(:profile).permit(
        :first_name, :last_name, :dob,
        :address, :state, :city, :country, :postcode, document_attributes: [:doc_type, :upload, :doc_expire, :doc_number, :id, :image_passport_file, :image_documnet_profile, :image_identity_card_file, :image_driver_license]
      )
    end

    def checkout_state
      if current_user.profile && (current_user.profile.state == "approved" || current_user.profile.state == "pending" )
        flash[:notice] = "Can't update KYC"
        redirect_to profiles_path
      end
    end
  end
end

