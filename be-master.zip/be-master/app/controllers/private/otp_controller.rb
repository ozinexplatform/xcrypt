module Private
  class OtpController < BaseController
    skip_before_action :login_must_be_confirm_two_factor!

    def create
      sms = current_user.sms_two_factor

      if params[:sms].present?
        sms.phone_number = params[:sms][:phone_number]
        sms.country = params[:sms][:country]
        sms.activated = true
      end
      sms.send_otp
      respond_to do |format|
        format.js
      end
    end

    def update
      sms = current_user.sms_two_factor
      sms.send_otp
      respond_to do |format|
        format.js
      end
    end
  end
end
