class Private::LoginTwoFactorController < ApplicationController
  before_action :auth_member!

  def index
    activated_two_factor = current_user.two_factors.activated.first || current_user.app_two_factor
    @activated_type = activated_two_factor.activated_type
  end

  def create
    app_auth = current_user.app_two_factor
    app_auth.otp = params[:otp]
    if app_auth.verify?
      session[:logged_in_2fa] = true
      redirect_to(after_sign_in_path_for(current_user))
    else
      redirect_to(:back, alert: app_auth.errors.full_messages.join("\n"))
    end
  end
end