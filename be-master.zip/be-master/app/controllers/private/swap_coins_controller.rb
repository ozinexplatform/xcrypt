# encoding: UTF-8
# frozen_string_literal: true

module Private
  class SwapCoinsController < BaseController
    layout "swap_coin"

    before_action :load_data_daily_limit, only: %i(index)
    before_action :check_verify_kyc, :check_daily_limit_system, :check_daily_limit_users, :check_amount_swap, only: %i(create)

    def index
      @swap_coin = current_user.coin_swaps.new
    end

    def create
      begin
        ActiveRecord::Base.transaction do
          swap_coin = current_user.coin_swaps.new swap_coin_params.merge(old_coin: "txt-o", new_coin: "txt")
          swap_coin.save!
          HandleSwapService.call(swap_coin_params, current_user)
        end  
      rescue ActiveRecord::ActiveRecordError
        return redirect_to swap_coins_path, notice: "Fail!, please try again."
      end
      redirect_to swap_coins_path, notice: "Swap successfully!"
    end

    private

    def load_data_daily_limit
      @amount_system = CoinSwap.all.in_date.sum(:old_coin_amount).to_f
      amount_user = current_user.coin_swaps.in_date.sum(:old_coin_amount).to_f
      @daily_limit_system = Const::SwapCoinDaily::SYSTEM.to_f - @amount_system
      @daily_limit_user = Const::SwapCoinDaily::USER.to_f - amount_user
      @txt_acount = current_user.accounts.find_by(currency_id: "txt")
      @txto_acount = current_user.accounts.find_by(currency_id: "txt-o")
      gon.can_swap = @daily_limit_system > 0
      @user_swaps = current_user.coin_swaps.lastest.page(params[:page_user]).per(Const::Paginate::DEFAULT)
      @system_swaps = CoinSwap.all.includes(:member).lastest.page(params[:page_system]).per(Const::Paginate::DEFAULT)
      @process_percent = (@amount_system/Const::SwapCoinDaily::SYSTEM) * 100
    end

    def swap_coin_params
      params.require(:coin_swap).permit(:old_coin_amount, :new_coin_amount)
    end

    def check_verify_kyc
      return redirect_to swap_coins_path, alert: "User KYC is required" unless current_user.profile.state == "approved"
    end
    
    def check_daily_limit_users
      amount_user = current_user.coin_swaps.in_date.sum(:old_coin_amount).to_f
      daily_limit_user = Const::SwapCoinDaily::USER.to_f - amount_user - params["coin_swap"]["old_coin_amount"].to_f
      return redirect_to swap_coins_path, alert: "User swap daily is 1,000 TXT-O" unless daily_limit_user >= 0
    end

    def check_amount_swap
      return redirect_to swap_coins_path, alert: "Amount must more than 0" unless params["coin_swap"]["old_coin_amount"].to_f > 0
      account_txt_o = current_user.accounts.find_by(currency_id: "txt-o")
      return redirect_to swap_coins_path, alert: "You don't enoungh coin to swap!" unless account_txt_o.balance >= params["coin_swap"]["old_coin_amount"].to_f
    end

    def check_daily_limit_system
      limit_amount = Rails.cache.read "coin_swap_system:#{Date.today.to_s}"
      return redirect_to swap_coins_path, alert: "System swap daily is 100,000 TXT-O" unless limit_amount.to_f <= (Const::SwapCoinDaily::SYSTEM - params["coin_swap"]["old_coin_amount"].to_f)
    end
  end
end
