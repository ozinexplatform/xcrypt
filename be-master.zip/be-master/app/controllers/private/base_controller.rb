# encoding: UTF-8
# frozen_string_literal: true

module Private
  class BaseController < ::ApplicationController
    before_filter :no_cache, :auth_member!, :login_must_be_confirm_two_factor!

    private

    def deposits_must_be_permitted!
      if current_user.level < ENV.fetch('MINIMUM_MEMBER_LEVEL_FOR_DEPOSIT').to_i
        redirect_to root_path, alert: t('private.settings.index.deposits_must_be_permitted')
      end
    end

    def withdraws_must_be_permitted!
      if current_user.level < ENV.fetch('MINIMUM_MEMBER_LEVEL_FOR_WITHDRAW').to_i
        redirect_to root_path, alert: t('private.settings.index.withdraws_must_be_permitted')
      end
    end

    def trading_must_be_permitted!
      if current_user.level < ENV.fetch('MINIMUM_MEMBER_LEVEL_FOR_TRADING').to_i
        redirect_to root_path, alert: t('private.settings.index.trading_must_be_permitted')
      end
    end

    def no_cache
      response.headers["Cache-Control"] = "no-cache, no-store, max-age=0, must-revalidate"
      response.headers["Pragma"] = "no-cache"
      response.headers["Expires"] = "Sat, 03 Jan 2009 00:00:00 GMT"
    end

    def login_must_be_confirm_two_factor!
      return redirect_to(login_two_factor_index_path) if 
        current_user.security.is_two_factor_login && session[:logged_in_2fa] != true
    end

    def sms_authentication_otp_valid!
      sms_auth = current_user.sms_two_factor
      sms_auth.otp = params[:otp]
      unless sms_auth.verify?
        redirect_to(:back, alert: sms_auth.errors.full_messages.join("\n")) and return
      end
    end

    def app_authentication_otp_valid!
      app_auth = current_user.app_two_factor
      app_auth.otp = params[:otp]
      unless app_auth.verify?
        redirect_to(:back, alert: app_auth.errors.full_messages.join("\n")) and return
      end
    end
  end
end
