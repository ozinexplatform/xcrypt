# encoding: UTF-8
# frozen_string_literal: true

module Private
  class RewardOnRefferalsController < ApplicationController
    def index
      return redirect_to root_path unless user_signed_in?

      @reffered_users = @current_member.reffered_users
    end

    private

    def user_signed_in?
      @current_member
    end
  end
end
