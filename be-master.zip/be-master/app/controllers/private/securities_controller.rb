module Private
  class SecuritiesController < BaseController
    before_action :set_security_and_app_and_sms

    def index
      @app_qr = RQRCode::QRCode.new( @app.uri, size: 8)
      @app = current_user.app_two_factor
      @sms = current_user.sms_two_factor
    end

    def update
      set_two_factor_type(params[:two_factor_type])
      @security.update(permit_params)

      if @security.errors.blank?
        redirect_to :back, notice: "Update Security successfully."
      else
        redirect_to :back, alert: @security.errors.full_messages.join("\n")
      end
    end

    private
      def set_security_and_app_and_sms
        @security = current_user.security
        @app = current_user.app_two_factor
        @sms = current_user.sms_two_factor
      end

      def permit_params
        params.require(:security).permit(:is_two_factor_login)
      end

      def set_two_factor_type(type)
        case type
          when "app"
            @app.active!
            current_user.two_factors.others(@app.id).map(&:deactive!)
          when "sms"
            @sms.active!
            current_user.two_factors.others(@sms.id).map(&:deactive!)
          else
            current_user.two_factors.map(&:deactive!)
        end
      end
  end
end
