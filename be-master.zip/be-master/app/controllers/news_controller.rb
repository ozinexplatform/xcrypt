# encoding: UTF-8
# frozen_string_literal: true

class NewsController < ApplicationController
  before_action :load_news_categories, :load_count, only: :index

  def index
    @news = News.joins(:news_category_mediates)
                .where(news_category_mediates: { news_category_id: news_category_id })
                .page(params[:page])
                .order('created_at DESC')
  end

  def show
    @news          = News.find_by(id: params[:id])
    @news_category = NewsCategory.find_by(id: params[:news_category_id])

    return redirect_to news_index_path(flash: { error: t('errors.news_not_found')}) unless @news && @news_category

    @news.update(views: @news.views.to_i + 1)
    @newses = News.joins(:news_category_mediates)
                  .where(news_category_mediates: { news_category_id: @news_category.id })
  end

  private

  def news_category_id
    @news_category_id ||=
      params[:news_category_id] || NewsCategory.find_by(name: "Official Announcement")&.id
  end

  def load_news_categories
    @news_categories = NewsCategory.where.not(name: 'Hot News')
                                   .order('id DESC')
  end

  def load_count
    @count = ((params[:page] || 1).to_i - 1) * 10
  end
end
