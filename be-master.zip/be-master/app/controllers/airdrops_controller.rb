# encoding: UTF-8
# frozen_string_literal: true

class AirdropsController < ApplicationController
  def index
  end
end
  