# encoding: UTF-8
# frozen_string_literal: true

class ClubsController < ApplicationController
  def index
  end
end
  