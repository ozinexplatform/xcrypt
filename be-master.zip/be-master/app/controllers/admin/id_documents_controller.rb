# encoding: UTF-8
# frozen_string_literal: true

module Admin
  class IdDocumentsController < BaseController
    before_action :load_member, only: %i(show update)

    def index
      @members = Document.includes(profile: :member)
    end

    def show;end

    def update
      if params[:level] && params[:level] == "highest"
        @member.update(level: 3)
        @member.profile.update_attributes(state: "approved", approved_at: DateTime.now)
      else
        if params[:type] == "rejected"
          @member.profile.update_attributes(state: params[:type], approved_at: nil)
          @member.update(level: 1)
        elsif params[:type] == "approved"
          @member.profile.update_attributes(state: params[:type], approved_at: DateTime.now)
          @member.update(level: 3)
        else
          @member.profile.update state: params[:type]
        end
      end
      # add_bonus
      redirect_to admin_id_document_path(@member), notice: "Successfully!"
    end

    private

    def load_member
      @member = Member.find params[:id]
    end

    def add_bonus
      return if Member.received_bonus.count > 3000
      return if @member.confirmed_at.nil?
      return if @member.bonus_register_flag
      return unless @member.profile.state == "approved"
      agvc_account, ozi_account = @member.accounts.where(currency_id: ["agvc", "ozi"]).order(:currency_id)
      agvc_account.plus_funds(100.0) if agvc_account
      ozi_account.plus_funds(150.0) if ozi_account
      @member.update_attributes(bonus_register_flag: true)
    end
  end
end