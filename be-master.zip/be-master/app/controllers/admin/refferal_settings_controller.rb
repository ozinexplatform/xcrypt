# encoding: UTF-8
# frozen_string_literal: true

module Admin
  class RefferalSettingsController < BaseController
    before_action :load_refferal_setting,
                  :load_form_options,
                  only: :index
    before_action :load_count, only: %i(index show)

    def index
      return redirect_to root_path unless user_signed_in?

      @users = Member.all
                     .includes(:refferals)
                     .references(:refferals)
                     .page(params[:page])
                     .group(['members.id', 'refferals.id'])
                     .order("COUNT(refferals.id) #{params[:sort] ||= 'DESC'}")
      @sort  = toggle_sort_option
    end

    def create
      refferal_setting = RefferalSetting.new(refferal_setting_params)

      if refferal_setting.save
        flash[:success] = "Setting success!"
      else
        flash[:alert] = refferal_setting.errors.full_messages.first
      end

      redirect_to admin_refferal_settings_path
    end

    def update
      refferal_setting = RefferalSetting.find_by(id: params[:id])

      if refferal_setting.update(refferal_setting_params)
        flash[:success] = "Setting success!"
      else
        flash[:alert] = refferal_setting.errors.full_messages.first
      end

      redirect_to admin_refferal_settings_path
    end

    def show
      @user           = Member.find_by(id: params[:id])
      @reffered_users = @user.reffered_users
                             .page(params[:page])
    end

    private

    def refferal_setting_params
      params.require(:refferal_setting).permit(:amount)
    end

    def load_refferal_setting
      @refferal_setting = RefferalSetting.first.presence || RefferalSetting.new
    end

    def load_form_options
      if @refferal_setting.new_record?
        @method = 'post'
        @path   = admin_refferal_settings_path
      else
        @method = 'patch'
        @path   = admin_refferal_setting_path @refferal_setting
      end
    end

    def user_signed_in?
      @current_member
    end

    def load_count
      @count = ((params[:page] || 1).to_i - 1) * 10
    end

    def toggle_sort_option
      params[:sort] == 'DESC' ? 'ASC' : 'DESC'
    end
  end
end
