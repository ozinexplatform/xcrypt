# encoding: UTF-8
# frozen_string_literal: true

module Admin
  class NewsController < BaseController
    skip_load_and_authorize_resource
    before_action :load_news, only: %i(edit update)
    before_action :load_data

    def index
      @newses = News.by_created_date(params)
                    .by_title(params[:title])
                    .includes(:news_categories)
                    .page(params[:page])
    end

    def new
      @news = News.new
    end

    def create
      @service = AdminService::News::CreateService.new(
        params: news_params,
        member: current_user,
        categories: params[:news_category_ids]
      )
      @service.perform

      if @service.valid
        flash[:success] = t('.success')
        redirect_to admin_news_index_path
      else
        flash.now[:alert] = @service.news.errors.full_messages.first
        render :new
      end
    end

    def edit
    end

    def update
      @service = AdminService::News::UpdateService.new(
        news: @news,
        params: news_params,
        member: current_user,
        categories: params[:news_category_ids]
      )
      @service.perform

      if @service.valid
        flash[:success] = t('.success')
        redirect_to admin_news_index_path
      else
        flash[:alert] = @service.news.errors.full_messages.first
        render :edit
      end
    end

    private

    def news_params
      params.require(:news).permit(News::NEWS_PARAMS).merge(member: current_user)
    end

    def load_data
      @news_categories = NewsCategory.pluck(:name, :id)
    end

    def load_news
      @news = News.find_by(id: params[:id])

      if @news.nil?
        flash[:alert] = t('.record_not_found', id: params[:id])
        redirect_to admin_news_index_path
      end
    end
  end
end
