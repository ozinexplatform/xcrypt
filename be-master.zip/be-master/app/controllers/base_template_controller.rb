# encoding: UTF-8
# frozen_string_literal: true

class BaseTemplateController < ApplicationController
  layout 'layouts/welcome_application'

  helper_method :page_info

  private
    def page_info
      raise "Not implement"
    end
end
