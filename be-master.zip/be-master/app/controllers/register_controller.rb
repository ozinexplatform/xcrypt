class RegisterController < BaseTemplateController

  def new
    @member = new_user
    # if params[:member].try(:[], :profile_attributes)
    #   @member.build_profile(first_name: params[:member][:profile_attributes])
    # end
    render :new, layout: 'layouts/login_application'
  end

  private 
    def page_info
      {}
    end

    def new_user
      if params[:member].blank?
        member = Member.new
        member.build_profile
        return member
      end
      Member.new params.require(:member).permit(:firstname, :lastname, :email, profile_attributes: [:first_name, :last_name])
    end
end
