class KycController < ApplicationController
end
