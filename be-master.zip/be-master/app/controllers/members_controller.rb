class MembersController < ApplicationController
  before_action :set_user, only: [:show, :edit, :update, :destroy]

  # GET /users/:id.:format
  def show
    # authorize! :read, @member
  end

  # GET /users/:id/edit
  def edit
    # authorize! :update, @member
  end

  # PATCH/PUT /users/:id.:format
  def update
    # authorize! :update, @member
    respond_to do |format|
      if @member.update(member_params)
        sign_in(@member == current_user ? @member : current_user, :bypass => true)
        format.html { redirect_to @member, notice: 'Your profile was successfully updated.' }
        format.json { head :no_content }
      else
        format.html { render action: 'edit' }
        format.json { render json: @member.errors, status: :unprocessable_entity }
      end
    end
  end

  # GET/PATCH /users/:id/finish_signup
  def finish_signup
    # authorize! :update, @member 
    if request.patch? && params[:member] #&& params[:member][:email]
      if @member.update(member_params)
        @member.skip_reconfirmation!
        sign_in(@member, :bypass => true)
        redirect_to @member, notice: 'Your profile was successfully updated.'
      else
        @show_errors = true
      end
    end
  end

  # DELETE /users/:id.:format
  def destroy
    # authorize! :delete, @member
    @member.destroy
    respond_to do |format|
      format.html { redirect_to root_url }
      format.json { head :no_content }
    end
  end
  
  private
    def set_user
      @member = Member.find(params[:id])
    end

    def user_params
      accessible = [ :name, :email ] # extend with your own params
      accessible << [ :password, :password_confirmation ] unless params[:member][:password].blank?
      params.require(:member).permit(accessible)
    end
end