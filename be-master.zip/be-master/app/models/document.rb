# frozen_string_literal: true

#
# Document
#
class Document < ActiveRecord::Base
  validates_lengths_from_database except: [:image_passport_file, :image_documnet_profile, :image_driver_license, :image_identity_card_file, :upload]
  mount_uploader :upload, UploadUploader
  mount_uploader :image_passport_file, UploadUploader
  mount_uploader :image_driver_license, UploadUploader
  mount_uploader :image_identity_card_file, UploadUploader
  mount_uploader :image_documnet_profile, UploadUploader

  TYPES = ['Passport', 'Identity card', 'Driver license'].freeze
  STATES = %w[verified pending rejected].freeze

  scope :kept, -> { joins(:profile).where(accounts: { discarded_at: nil }) }

  belongs_to :profile
  serialize :metadata, JSON
  validates :doc_type, :doc_number, :doc_expire, presence: true
  validates :doc_type, inclusion: { in: TYPES }

  validates :doc_number, length: { maximum: 128 },
                         format: {
                           with: /\A[A-Za-z0-9\-\s]+\z/,
                           message: 'only allows letters and digits'
                         }, if: proc { |a| a.doc_number.present? }
  validates_format_of :doc_expire,
                      with: /\A\d{4}\-\d{2}\-\d{2}\z/,
                      message: 'Date must be in the following format: yyyy-mm-dd'
  validate :doc_expire_not_in_the_past
  # after_commit :create_or_update_document_label, on: :create

  def self.search(field: nil, term: nil)
    case field
      when 'email', 'sn'
        where("members.#{field} LIKE ?", "%#{term}%")
      else
        all
    end.order(:id).reverse_order
  end

private

  def doc_expire_not_in_the_past
    return if doc_expire.blank?
    errors.add(:doc_expire, :invalid) if doc_expire < Date.current
  end

  # def create_or_update_document_label
  #   profile_document_label = profile.labels.find_by(key: :document)
  #   if profile_document_label.nil?
  #     profile.labels.create(key: :document, value: :pending, scope: :private)
  #   elsif profile_document_label.value != 'verified'
  #     profile_document_label.update(value: :pending)
  #   end
  # end
end


# == Schema Information
# Schema version: 20190519132546
#
# Table name: documents
#
#  id                       :integer          not null, primary key
#  profile_id               :integer
#  upload                   :string(255)
#  doc_type                 :string(255)
#  doc_number               :string(255)
#  doc_expire               :date
#  created_at               :datetime
#  updated_at               :datetime
#  image_passport_file      :string(255)
#  image_documnet_profile   :string(255)
#  image_identity_card_file :string(255)
#  image_driver_license     :string(255)
#
# Indexes
#
#  fk_rails_e8a54dd096  (profile_id)
#
# Foreign Keys
#
#  fk_rails_e8a54dd096  (profile_id => profiles.id)
#
