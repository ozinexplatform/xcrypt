class CoinSwap < ActiveRecord::Base
  include BelongsToMember

  scope :in_date, -> { where("Date(created_at) = ?", Date.today)}
  scope :lastest, -> { order(created_at: :desc) }

  after_create :store_daily_limit_system

  private
  
  def store_daily_limit_system
    amount_system = CoinSwap.all.in_date.sum(:old_coin_amount).to_f
    Rails.cache.write("coin_swap_system:#{Date.today.to_s}", amount_system)
  end

  def time_expires
    time_now = DateTime.now.to_i
    end_time = DateTime.now.end_of_day.to_i
    end_time - time_now
  end
end

# == Schema Information
# Schema version: 20190701021401
#
# Table name: coin_swaps
#
#  id              :integer          not null, primary key
#  old_coin        :string(255)
#  new_coin        :string(255)
#  old_coin_amount :decimal(32, 16)  default(0.0), not null
#  new_coin_amount :decimal(32, 16)  default(0.0), not null
#  member_id       :integer
#  created_at      :datetime         not null
#  updated_at      :datetime         not null
#
