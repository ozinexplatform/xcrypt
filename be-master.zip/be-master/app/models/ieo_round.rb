# encoding: UTF-8
# frozen_string_literal: true

class IeoRound < ActiveRecord::Base
  belongs_to :ieo_project

  has_many :ieo_round_sessions
end

# == Schema Information
# Schema version: 20190707174900
#
# Table name: ieo_rounds
#
#  id               :integer          not null, primary key
#  ieo_project_id   :integer          not null
#  start_time       :datetime         not null
#  end_time         :datetime         not null
#  round_supply     :integer          not null
#  remaining_amount :integer          not null
#  bonus            :decimal(5, 2)    default(0.0)
#  refferal         :decimal(5, 2)    default(0.0)
#  note             :string(255)
#  status           :integer          default(0), not null
#  member_id        :integer
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#
