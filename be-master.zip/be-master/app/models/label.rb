class Label < ActiveRecord::Base
end

# == Schema Information
# Schema version: 20190430035618
#
# Table name: labels
#
#  id         :integer          not null, primary key
#  member_id  :integer
#  key        :string(255)      not null
#  value      :string(255)      not null
#  scope      :string(255)      default("public"), not null
#  created_at :datetime
#  updated_at :datetime
#
# Indexes
#
#  fk_rails_b50b039f7b                          (member_id)
#  index_labels_on_key_and_value_and_member_id  (key,value,member_id) UNIQUE
#
# Foreign Keys
#
#  fk_rails_b50b039f7b  (member_id => members.id) ON DELETE => cascade
#
