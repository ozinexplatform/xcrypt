class RefferalSetting < ActiveRecord::Base
end

# == Schema Information
# Schema version: 20190614174622
#
# Table name: refferal_settings
#
#  id         :integer          not null, primary key
#  amount     :decimal(6, 4)    default(0.0), not null
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
