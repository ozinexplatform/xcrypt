class TwoFactor < ActiveRecord::Base
  belongs_to :member

  before_validation :gen_code, on: :create
  # after_update :send_notification

  validates :member, :otp_secret, :refreshed_at, presence: true
  validates :member_id, uniqueness: {scope: :activated, if: :type_active_present?}

  attr_accessor :otp

  SUBCLASS = %w[app sms ema].freeze

  validates :type, uniqueness: {scope: :member_id}

  scope :activated, -> { where(activated: true) }
  scope :others, ->(id) {where.not(id: id)}

  class << self
    def by_type(type)
      # return unless SUBCLASS.include?(type.to_s)
      raise InvalidInput.new(
        message: "Unknown OTP type",
        type:    "Parameter Invalid"
      ) unless SUBCLASS.include?(type.to_s)

      klass = "two_factor/#{type}".camelize.constantize
      klass.find_or_create_by(type: klass.name)
    end

    def activated?
      activated.any?
    end
  end

  def type_active_present?
    TwoFactor.where.not(id: id).find_by(member_id: member_id, activated: true).present?
  end

  # return sms or app or ema
  def activated_type
    type.split(//).last(3).join("").to_s.downcase
  end

  def verify?
    msg = "#{self.class.name}#verify? is not implemented."
    raise NotImplementedError.new(msg)
  end

  def expired?
    Time.current >= 30.minutes.since(refreshed_at)
  end

  def refresh!
    gen_code
    save
  end

  def enable!
    update is_enabled: true
  end

  def disable!
    update is_enabled: false
  end

  def active!
    update activated: true, last_verify_at: Time.now
  end

  def deactive!
    update activated: false
  end

  private

  def gen_code
    msg = "#{self.class.name}#gen_code is not implemented."
    raise NotImplementedError.new(msg)
  end

  def send_notification
    msg = "#{self.class.name}#send_notification is not implemented."
    raise NotImplementedError.new(msg)
  end
end

# == Schema Information
# Schema version: 20190505062419
#
# Table name: two_factors
#
#  id             :integer          not null, primary key
#  member_id      :integer
#  otp_secret     :string(255)
#  type           :string(255)
#  last_verify_at :datetime
#  activated      :boolean          default(FALSE)
#  is_enabled     :boolean          default(FALSE)
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#  refreshed_at   :datetime
#
# Indexes
#
#  fk_rails_29f59babd9  (member_id)
#
# Foreign Keys
#
#  fk_rails_29f59babd9  (member_id => members.id)
#
