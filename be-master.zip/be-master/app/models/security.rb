class Security < ActiveRecord::Base
end

# == Schema Information
# Schema version: 20190504141230
#
# Table name: securities
#
#  id                  :integer          not null, primary key
#  is_two_factor_login :boolean          default(FALSE)
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#  member_id           :integer
#
# Indexes
#
#  index_securities_on_member_id  (member_id)
#
