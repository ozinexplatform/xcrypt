module Const
  module SwapCoinDaily
    SYSTEM = 100000
    USER = 1000
    BaseUserEmail = "base_account@yopmail.com"
  end

  module Paginate
    DEFAULT = 10
  end
end