class NewsCategory < ActiveRecord::Base
  has_many :news
  has_many :news_category_mediates

  validates :name, presence: true, length: { maximum: 128 }
  validates :memo, length: { maximum: 255 }
end

# == Schema Information
# Schema version: 20190504141827
#
# Table name: news_categories
#
#  id         :integer          not null, primary key
#  name       :string(128)      not null
#  memo       :string(255)
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
# Indexes
#
#  index_news_categories_on_name  (name)
#
