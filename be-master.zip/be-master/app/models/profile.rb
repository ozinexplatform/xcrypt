class Profile < ActiveRecord::Base
  has_one :document, dependent: :destroy
  belongs_to :member

  accepts_nested_attributes_for :document, allow_destroy: true
end

# == Schema Information
# Schema version: 20190620012536
#
# Table name: profiles
#
#  id            :integer          not null, primary key
#  member_id     :integer
#  first_name    :string(255)
#  last_name     :string(255)
#  dob           :date
#  address       :string(255)
#  postcode      :string(255)
#  city          :string(255)
#  country       :string(255)
#  state         :string(255)      default("submit"), not null
#  created_at    :datetime
#  updated_at    :datetime
#  phone_number  :string(255)
#  country_phone :string(255)
#  approved_at   :datetime
#
# Indexes
#
#  fk_rails_06fabe887f  (member_id)
#
# Foreign Keys
#
#  fk_rails_06fabe887f  (member_id => members.id)
#
