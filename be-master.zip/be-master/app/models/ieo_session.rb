# encoding: UTF-8
# frozen_string_literal: true

class IeoSession < ActiveRecord::Base
  has_many :ieo_round_sessions
end

# == Schema Information
# Schema version: 20190707174900
#
# Table name: ieo_sessions
#
#  id          :integer          not null, primary key
#  currency_id :string(255)      not null
#  status      :integer          default(0), not null
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#
