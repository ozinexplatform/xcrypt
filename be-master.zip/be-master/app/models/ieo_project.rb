# encoding: UTF-8
# frozen_string_literal: true

class IeoProject < ActiveRecord::Base
  has_many :ieo_rounds
end

# == Schema Information
# Schema version: 20190707174900
#
# Table name: ieo_projects
#
#  id                       :integer          not null, primary key
#  name                     :string(10)       not null
#  full_name                :string(32)       not null
#  logo                     :string(255)
#  total_supply             :integer          not null
#  listing_time             :datetime
#  ieo_ceiling              :integer
#  ieo_minimum              :integer
#  technological_foundation :string(255)      not null
#  website                  :string(255)
#  whitepaper               :string(255)
#  telegram                 :string(255)
#  kakao                    :string(255)
#  twiter                   :string(255)
#  facebook                 :string(255)
#  wechat                   :string(255)
#  short_describer          :string(255)      not null
#  long_describer           :string(255)      not null
#  introduction             :string(255)      not null
#  tips                     :string(255)
#  member_id                :integer
#  created_at               :datetime         not null
#  updated_at               :datetime         not null
#
