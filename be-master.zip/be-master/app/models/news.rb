# encoding: UTF-8
# frozen_string_literal: true

class News < ActiveRecord::Base
  mount_uploader :banner, BannerUploader

  NEWS_PARAMS = %i(title content source enabled show_banner banner banner_cache).freeze
  MAX_SIZE    = 10.megabytes

  paginates_per 10

  belongs_to :member

  has_many :news_category_mediates
  has_many :news_categories, through: :news_category_mediates

  validates :title, presence: true, length: { maximum: 128 }
  validates :content, presence: true, length: { maximum: 65535 }
  validates :source, length: { maximum: 1000 }

  validate :validate_banner_size
  validates_lengths_from_database except: [:banner]

  delegate :name, to: :news_category, prefix: true

  enum show_banner: { show: true, hide: false }
  enum enabled: { enable: true, disable: false }

  scope :by_created_date, (lambda do |condition|
    case
    when condition[:from_date].present? && condition[:to_date].present?
      where("DATE(created_at) BETWEEN ? AND ?",
        condition[:from_date],
        condition[:to_date]
      )
    when condition[:from_date].present? && condition[:to_date].blank?
      where("DATE(created_at) >= ?", condition[:from_date])
    when condition[:from_date].blank? && condition[:to_date].present?
      where("DATE(created_at) <= ?", condition[:to_date])
    end
  end)

  scope :by_title, (lambda do |title|
    where("title LIKE ?", "%#{title}%")
  end)

  private

  def validate_banner_size
    errors.add(:banner, :max_size) if banner.size > MAX_SIZE
  end
end

# == Schema Information
# Schema version: 20190608033301
#
# Table name: news
#
#  id          :integer          not null, primary key
#  title       :string(128)      not null
#  content     :text(65535)      not null
#  source      :string(1000)
#  views       :integer
#  member_id   :integer
#  created_at  :datetime         not null
#  updated_at  :datetime         not null
#  banner      :string(255)
#  enabled     :boolean          default(TRUE)
#  show_banner :boolean          default(TRUE)
#
# Indexes
#
#  index_news_on_member_id  (member_id)
#
# Foreign Keys
#
#  fk_rails_fce1ae2954  (member_id => members.id)
#
