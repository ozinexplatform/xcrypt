# encoding: UTF-8
# frozen_string_literal: true

require 'securerandom'

class Member < ActiveRecord::Base
  # Include default devise modules. Others available are:
  # :confirmable, :lockable, :timeoutable, :trackable and :omniauthable

  TEMP_EMAIL_PREFIX = 'change@me'
  TEMP_EMAIL_REGEX = /\Achange@me/

  devise :database_authenticatable, :registerable, :confirmable,
    :recoverable, :rememberable, :trackable, :validatable, :omniauthable

  has_one :identity
  has_one :profile, dependent: :destroy
  has_one :security, dependent: :destroy

  # has_many :documents, dependent: :destroy
  has_many :coin_swaps
  has_many :labels, dependent: :destroy
  has_many :orders
  has_many :accounts
  has_many :payment_addresses, through: :accounts
  has_many :withdraws, -> { order(id: :desc) }
  has_many :deposits, -> { order(id: :desc) }
  has_many :authentications, dependent: :delete_all
  has_many :two_factors, dependent: :delete_all
  has_many :refferals, foreign_key: :reffered_by
  has_many :reffered_users, through: :refferals, source: :member

  scope :enabled, -> { where(disabled: false) }
  scope :received_bonus, -> {where(bonus_register_flag: true)}

  before_validation :downcase_email, :assign_sn

  validates :sn,    presence: true, uniqueness: true
  validates :email, presence: true, uniqueness: true, email: true
  validates :level, numericality: { greater_than_or_equal_to: 0 }

  PASSWORD_FORMAT = /\A
  (?=.{6,})          # Must contain 6 or more characters
  (?=.*\d)           # Must contain a digit
  (?=.*[a-z])        # Must contain a lower case character
  (?=.*[A-Z])        # Must contain an upper case character
  /x

  validates :password, presence: true, length: { minimum: 6, maximum: 64 }, format: { with: PASSWORD_FORMAT }, confirmation: true, unless: "password.nil?"
  validates :password_confirmation, presence: true, length: { minimum: 6, maximum: 64 }, format: { with: PASSWORD_FORMAT }, confirmation: true, unless: "password.nil?"

  after_create :touch_accounts, :touch_security

  attr_readonly :email

  accepts_nested_attributes_for :profile

  def self.find_for_oauth(auth, signed_in_resource = nil)

    # Get the identity and member if they exist
    identity = Identity.find_for_oauth(auth)

    # If a signed_in_resource is provided it always overrides the existing member
    # to prevent the identity being locked with accidentally created accounts.
    # Note that this may leave zombie accounts (with no associated identity) which
    # can be cleaned up at a later date.
    member = signed_in_resource ? signed_in_resource : identity.member

    # Create the member if needed
    if member.nil?

      # Get the existing member by email if the provider gives us a verified email.
      # If no verified email was provided we assign a temporary email and ask the
      # member to verify it on the next step via UsersController.finish_signup
      email_is_verified = auth.info.email && (auth.info.verified || auth.info.verified_email)
      email = auth.info.email if email_is_verified
      member = Member.where(:email => email).first if email

      # Create the user if it's a new registration
      if member.nil?
        member = Member.new(
          #username: auth.info.nickname || auth.uid,
          email: email ? email : "#{TEMP_EMAIL_PREFIX}-#{auth.uid}-#{auth.provider}.com",
          password: Devise.friendly_token[0,20]
        )
        member.skip_confirmation!
        member.save!
      end
    end

    # Associate the identity with the member if needed
    if identity.member != member
      identity.member = member
      identity.save!
    end
    member
  end

  def self.new_with_session params, session
    super.tap do |user|
      if data = session["devise.facebook_data"] &&
        session["devise.facebook_data"]["extra"]["raw_info"]
        user.email = data["email"] if user.email.blank?
      end
    end
  end

  def self.from_omniauth auth
    where(provider: auth.provider, uid: auth.uid).first_or_create do |user|
      user.email = auth.info.email
      user.password = Devise.friendly_token[0,20]
      user.name = auth.info.name
    end
  end

  def email_verified?
    self.email && self.email !~ TEMP_EMAIL_REGEX
  end

  def active_for_authentication?
    super && !self.disabled?
  end

  def inactive_message
    super
  end

  class << self
    def from_auth(auth_hash)
      member = locate_auth(auth_hash) || locate_email(auth_hash) || Member.new
      member.tap do |member|
        member.transaction do
          info_hash       = auth_hash.fetch('info')
          member.email    = info_hash.fetch('email')
          member.level    = info_hash['level'] if info_hash.key?('level')
          member.disabled = info_hash.key?('state') && info_hash['state'] != 'active'
          member.save!
          auth = Authentication.locate(auth_hash) || member.authentications.from_omniauth_data(auth_hash)
          auth.token = auth_hash.dig('credentials', 'token')
          auth.save!
        end
      end
    rescue => e
      report_exception(e)
      Rails.logger.debug { "OmniAuth data: #{auth_hash.to_json}." }
      Rails.logger.debug { "Member: #{member.to_json}." } if member
      raise e
    end

    def current
      Thread.current[:user]
    end

    def current=(user)
      Thread.current[:user] = user
    end

    def admins
      Figaro.env.admin.split(',').map(&:squish)
    end

    def search(field: nil, term: nil)
      case field
        when 'email', 'sn'
          where("members.#{field} LIKE ?", "%#{term}%")
        when 'wallet_address'
          joins(:payment_addresses).where('payment_addresses.address LIKE ?', "%#{term}%")
        else
          all
      end.order(:id).reverse_order
    end


    private

    def locate_auth(auth_hash)
      Authentication.locate(auth_hash).try(:member)
    end

    def locate_email(auth_hash)
      find_by_email(auth_hash.dig('info', 'email'))
    end
  end

  def trades
    Trade.where('bid_member_id = ? OR ask_member_id = ?', id, id)
  end

  def admin?
    @is_admin ||= self.class.admins.include?(self.email)
  end

  def get_account(model_or_id_or_code)
    accounts.with_currency(model_or_id_or_code).first.yield_self do |account|
      touch_accounts unless account
      accounts.with_currency(model_or_id_or_code).first
    end
  end
  alias :ac :get_account

  def touch_accounts
    Currency.find_each do |currency|
      next if accounts.where(currency: currency).exists?
      accounts.create!(currency: currency)
    end
  end

  def touch_security
    create_security
  end

  def auth(name)
    authentications.where(provider: name).first
  end

  def auth_with?(name)
    auth(name).present?
  end

  def remove_auth(name)
    auth(name).destroy
  end

  def uid
    self.class.uid(self)
  end

  def trigger_pusher_event(event, data)
    self.class.trigger_pusher_event(self, event, data)
  end

  def app_two_factor
    two_factors.by_type(:app)
  end

  def sms_two_factor
    two_factors.by_type(:sms)
  end

  def send_devise_notification(notification, *args)
    devise_mailer.send(notification, self, *args).deliver_later
  end

private

  def downcase_email
    self.email = email.try(:downcase)
  end

  def assign_sn
    return unless sn.blank?
    begin
      self.sn = random_sn
    end while Member.where(sn: self.sn).any?
  end

  def random_sn
    "SN#{SecureRandom.hex(5).upcase}"
  end

  class << self
    def uid(member_or_id)
      id  = self === member_or_id ? member_or_id.id : member_or_id
      uid = Authentication.barong.where(member_id: id).limit(1).pluck(:uid).first
      if uid.blank?
        self === member_or_id ? member_or_id.sn : Member.where(id: id).limit(1).pluck(:sn).first
      else
        uid
      end
    end

    def trigger_pusher_event(member_or_id, event, data)
      AMQPQueue.enqueue :pusher_member, \
        member_id: self === member_or_id ? member_or_id.id : member_or_id,
        event:     event,
        data:      data
    end
  end
end

# == Schema Information
# Schema version: 20190617023504
#
# Table name: members
#
#  id                     :integer          not null, primary key
#  level                  :integer          default(0), not null
#  sn                     :string(12)       not null
#  email                  :string(255)      not null
#  disabled               :boolean          default(FALSE), not null
#  api_disabled           :boolean          default(FALSE), not null
#  created_at             :datetime         not null
#  updated_at             :datetime         not null
#  encrypted_password     :string(255)      default(""), not null
#  reset_password_token   :string(255)
#  reset_password_sent_at :datetime
#  remember_created_at    :datetime
#  sign_in_count          :integer          default(0), not null
#  current_sign_in_at     :datetime
#  last_sign_in_at        :datetime
#  current_sign_in_ip     :string(255)
#  last_sign_in_ip        :string(255)
#  confirmation_token     :string(255)
#  confirmed_at           :datetime
#  confirmation_sent_at   :datetime
#  unconfirmed_email      :string(255)
#  bonus_register_flag    :boolean          default(FALSE)
#  bonus_register_at      :datetime
#
# Indexes
#
#  index_members_on_disabled              (disabled)
#  index_members_on_email                 (email) UNIQUE
#  index_members_on_reset_password_token  (reset_password_token) UNIQUE
#  index_members_on_sn                    (sn) UNIQUE
#
