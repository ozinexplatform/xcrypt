# encoding: UTF-8
# frozen_string_literal: true

class NewsCategoryMediate < ActiveRecord::Base
  belongs_to :news
  belongs_to :news_category

  with_options presence: true do
    validates :news_id
    validates :news_category_id
  end
end

# == Schema Information
# Schema version: 20190525034830
#
# Table name: news_category_mediates
#
#  id               :integer          not null, primary key
#  news_id          :integer          not null
#  news_category_id :integer          not null
#  created_at       :datetime         not null
#  updated_at       :datetime         not null
#
# Indexes
#
#  index_news_category_mediates_on_news_category_id  (news_category_id)
#  index_news_category_mediates_on_news_id           (news_id)
#
# Foreign Keys
#
#  fk_rails_32e19ddad9  (news_category_id => news_categories.id)
#  fk_rails_e31d918a45  (news_id => news.id)
#
