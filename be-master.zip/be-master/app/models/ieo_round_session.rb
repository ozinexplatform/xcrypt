# encoding: UTF-8
# frozen_string_literal: true

class IeoRoundSession < ActiveRecord::Base
  belongs_to :ieo_round
  belongs_to :ieo_session
end

# == Schema Information
# Schema version: 20190707174900
#
# Table name: ieo_round_sessions
#
#  id             :integer          not null, primary key
#  ieo_session_id :integer          not null
#  ieo_round_id   :integer          not null
#  token_amount   :integer          not null
#  session_amount :decimal(32, 16)  not null
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#
