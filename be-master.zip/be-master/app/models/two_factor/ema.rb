class TwoFactor::Ema < ::TwoFactor
end

# == Schema Information
# Schema version: 20190505062419
#
# Table name: two_factors
#
#  id             :integer          not null, primary key
#  member_id      :integer
#  otp_secret     :string(255)
#  type           :string(255)
#  last_verify_at :datetime
#  activated      :boolean          default(FALSE)
#  is_enabled     :boolean          default(FALSE)
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#  refreshed_at   :datetime
#
# Indexes
#
#  fk_rails_29f59babd9  (member_id)
#
# Foreign Keys
#
#  fk_rails_29f59babd9  (member_id => members.id)
#
