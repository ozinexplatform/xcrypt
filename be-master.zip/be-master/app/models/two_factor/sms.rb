class TwoFactor::Sms < ::TwoFactor
  attr_accessor :send_code_phase
  attr_accessor :country, :phone_number

  validates :phone_number, presence: {if: :send_code_phase}
  validate :valid_phone_number_for_country

  def verify?
    if !expired? && otp_secret == otp
      touch(:last_verify_at)
      refresh!
      true
    else
      if otp.blank?
        errors.add :otp, :blank
      else
        errors.add :otp, :invalid
      end
      false
    end
  end

  def otp_valid?
    !expired? && otp_secret == otp
  end

  def sms_message
    I18n.t("sms.verification_code", code: otp_secret)
  end

  # send otp code to phone
  def send_otp phone_number=nil
    refresh! if expired?
    # update_phone_number_to_member if send_code_phase
    if self.activated
      pn = phone_number || self.phone_number || self.member.profile.phone_number
      ct = country || self.country || self.member.profile.country_phone
      phone = Phonelib.parse(pn, ct).international
      SendSmsJob.perform_later(phone, sms_message)
    else
      TokenMailer.send_code(self.member, self.otp_secret).deliver_later!
    end
    # AMQPQueue.enqueue(:sms_notification, phone: phone, message: sms_message)
  end

  # send otp code to mail
  def send_mail
    refresh! if expired?
    TokenMailer.send_code(member.email, otp_secret).deliver if member.activated
  end

  def send_mail_regist_twofa
    refresh! if expired?
    TokenMailer.send_code(member.email, otp_secret).deliver if member.activated
  end

  def unactived
    self.activated = nil
    self.last_verify_at = nil
    save
  end

  def country_code
    ISO3166::Country[country].try :country_code
  end

  def phone_with_country
    Phonelib.parse(pn, country).international
  end

  def update_profile
    member.profile.update_attributes(country_phone: self.country, phone_number: self.phone_number)
  end

  def reset_profile
    member.profile.update_attributes(country_phone: nil, phone_number: nil)
  end

  private

  def valid_phone_number_for_country
    return unless send_code_phase
    errors.add :phone_number, :country_invalid if Phonelib.invalid_for_country?(phone_number, country)
  end

  def gen_code
    self.otp_secret = "%06d" % SecureRandom.random_number(1_000_000)
    self.refreshed_at = Time.now
  end

  def send_notification
    return unless activated_changed?

    if activated
      MemberMailer.sms_auth_activated(member.id).deliver
    else
      MemberMailer.sms_auth_deactivated(member.id).deliver
    end
  end
end

# == Schema Information
# Schema version: 20190505062419
#
# Table name: two_factors
#
#  id             :integer          not null, primary key
#  member_id      :integer
#  otp_secret     :string(255)
#  type           :string(255)
#  last_verify_at :datetime
#  activated      :boolean          default(FALSE)
#  is_enabled     :boolean          default(FALSE)
#  created_at     :datetime         not null
#  updated_at     :datetime         not null
#  refreshed_at   :datetime
#
# Indexes
#
#  fk_rails_29f59babd9  (member_id)
#
# Foreign Keys
#
#  fk_rails_29f59babd9  (member_id => members.id)
#
