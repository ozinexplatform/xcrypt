class Refferal < ActiveRecord::Base
  belongs_to :member, foreign_key: :reffered_user
end

# == Schema Information
# Schema version: 20190614174622
#
# Table name: refferals
#
#  id                  :integer          not null, primary key
#  refferal_setting_id :integer
#  reffered_by         :integer
#  reffered_user       :integer
#  created_at          :datetime         not null
#  updated_at          :datetime         not null
#
# Indexes
#
#  index_refferals_on_refferal_setting_id  (refferal_setting_id)
#  index_refferals_on_reffered_by          (reffered_by)
#
