class Identity < ActiveRecord::Base
  belongs_to :member

  validates_presence_of :uid, :provider
  validates_uniqueness_of :uid, :scope => :provider

  def self.find_for_oauth(auth)
    find_or_create_by(uid: auth.uid, provider: auth.provider)
  end
end

# == Schema Information
# Schema version: 20190318135318
#
# Table name: identities
#
#  id         :integer          not null, primary key
#  member_id  :integer
#  provider   :string(255)
#  uid        :string(255)
#  created_at :datetime         not null
#  updated_at :datetime         not null
#
# Indexes
#
#  index_identities_on_member_id  (member_id)
#
# Foreign Keys
#
#  fk_rails_a2a2aa200f  (member_id => members.id)
#
