# encoding: UTF-8
# frozen_string_literal: true

module NewsHelper
  def active_category_btn id, current_id
    current_id.to_i == id ? 'active nav-link' : 'nav-link'
  end

  def announcement_time news
    "Time: #{ news.created_at.strftime("%y-%m-%d") }"
  end

  def announcement_views news
    "Views: #{ news.views.to_i }"
  end

  def announcement_categories news
    "Categories: #{news.news_categories.pluck(:name).join(', ')}"
  end
end
