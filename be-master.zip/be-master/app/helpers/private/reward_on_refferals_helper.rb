# encoding: UTF-8
# frozen_string_literal: true

module Private::RewardOnRefferalsHelper
  def hide_user_email email
    email.gsub(/(?<=.{3}).*@.*(?=\S{3})/, '****@****')
  end

  def reffered_user_level user
    "level #{user.level} in review"
  end
end
