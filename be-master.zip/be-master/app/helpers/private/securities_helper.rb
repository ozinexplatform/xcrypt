module Private::SecuritiesHelper

  def security_app_helper_path(app)
    return deactive_app_authentication_index_path if app.is_enabled
    active_app_authentication_index_path
  end

  def security_sms_helper_path(sms)
    return deactive_sms_authentication_index_path if sms.is_enabled
    active_sms_authentication_index_path
  end
end
