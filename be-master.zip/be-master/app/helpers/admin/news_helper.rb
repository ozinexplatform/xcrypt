# encoding: UTF-8
# frozen_string_literal: true
module Admin
  module NewsHelper
    def category_checked? id, category_ids
      return false if params[:news_category_ids].nil? && category_ids.blank?

      checked = if (params[:news_category_ids] || category_ids.map(&:to_s)).include? id.to_s
                  true
                else
                  false
                end
    end
  end
end
