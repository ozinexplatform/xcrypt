module EmailHelper
  def email_image_tag(image, **options)
    attachments.inline[image] = {
        :content => Base64.encode64(File.read(Rails.root.join("app/assets/images/#{image}"))),
        :mime_type => "image/png",
        # :encoding => "base64"
    }
    image_tag "data:image/png;base64,#{attachments[image].read}", **options
  end
end