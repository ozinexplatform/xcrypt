class AddColoumnToDocuments < ActiveRecord::Migration
  def change
    add_column :documents, :image_document_file, :string
    add_column :documents, :image_documnet_profile, :string
  end
end
