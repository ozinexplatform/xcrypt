class CreateNewsCategoryMediates < ActiveRecord::Migration
  def change
    create_table :news_category_mediates do |t|
      t.references :news,          index: true, foreign_key: true, null: false
      t.references :news_category, index: true, foreign_key: true, null: false

      t.timestamps null: false
    end
  end
end
