class AddPhoneNumberAndCountryToProfile < ActiveRecord::Migration
  def change
    add_column :profiles, :phone_number, :string
    add_column :profiles, :country_phone, :string
  end
end
