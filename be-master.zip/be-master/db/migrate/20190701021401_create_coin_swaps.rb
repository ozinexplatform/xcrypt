class CreateCoinSwaps < ActiveRecord::Migration
  def change
    create_table :coin_swaps do |t|
      t.string :old_coin
      t.string :new_coin
      t.decimal :old_coin_amount, precision: 32, scale: 16, default: 0.0,
        null: false
      t.decimal :new_coin_amount, precision: 32, scale: 16, default: 0.0,
        null: false
      t.references :member

      t.timestamps null: false
    end
  end
end
