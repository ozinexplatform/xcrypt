class CreateRefferalSettings < ActiveRecord::Migration
  def change
    create_table :refferal_settings do |t|
      t.decimal :amount, precision: 6, scale: 4, default: 0.0,  null: false

      t.timestamps null: false
    end
  end
end
