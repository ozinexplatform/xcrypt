class CreateTwoFactors < ActiveRecord::Migration
  def change
    create_table :two_factors do |t|
      t.references :member, foreign_key: true
      t.string :otp_secret
      t.string :type
      t.datetime :last_verify_at
      t.boolean :activated, default: false
      t.boolean :is_enabled, default: false

      t.timestamps :refreshed_at
      t.timestamps null: false
    end
  end
end
