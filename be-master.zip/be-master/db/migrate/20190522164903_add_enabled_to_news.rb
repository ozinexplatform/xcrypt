class AddEnabledToNews < ActiveRecord::Migration
  def change
    add_column :news, :enabled, :boolean, default: true
  end
end
