class AddForeignKeyForSecurities < ActiveRecord::Migration
  def change
    add_reference :securities, :member, index: true
  end
end
