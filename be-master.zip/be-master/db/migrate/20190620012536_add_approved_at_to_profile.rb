class AddApprovedAtToProfile < ActiveRecord::Migration
  def change
    add_column :profiles, :approved_at, :datetime
  end
end
