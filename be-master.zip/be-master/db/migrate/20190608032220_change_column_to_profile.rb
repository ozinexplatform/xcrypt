class ChangeColumnToProfile < ActiveRecord::Migration
  def change
    change_column :profiles, :state, :string, default: "submit", null: false
  end
end
