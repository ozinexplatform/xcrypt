class UpdateColumnToDocuments < ActiveRecord::Migration
  def change
    add_column :documents, :image_identity_card_file, :string
    add_column :documents, :image_driver_license, :string
    rename_column :documents, :image_document_file, :image_passport_file
  end
end
