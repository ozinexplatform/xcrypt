class CreateRefferals < ActiveRecord::Migration
  def change
    create_table :refferals do |t|
      t.references :refferal_setting, index: true
      t.integer :reffered_by        , index: true
      t.integer :reffered_user

      t.timestamps null: false
    end
  end
end
