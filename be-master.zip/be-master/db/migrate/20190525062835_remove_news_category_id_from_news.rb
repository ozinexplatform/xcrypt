class RemoveNewsCategoryIdFromNews < ActiveRecord::Migration
  def change
    remove_reference :news, :news_category, index: true, foreign_key: true
  end
end
