class CreateIeoRounds < ActiveRecord::Migration
  def change
    create_table :ieo_rounds do |t|
      t.integer :ieo_project_id,    null: false
      t.datetime :start_time,       null: false
      t.datetime :end_time,         null: false
      t.integer :round_supply,      null: false
      t.integer :remaining_amount,  null: false
      t.decimal :bonus,                          precision: 5, scale: 2, default: 0.0
      t.decimal :refferal,                       precision: 5, scale: 2, default: 0.0
      t.string :note
      t.integer :status,            null: false,                         default: 0
      t.integer :member_id

      t.timestamps null: false
    end
  end
end
