class AddRefreshedAtToTwofactors < ActiveRecord::Migration
  def change
    add_column :two_factors, :refreshed_at, :datetime
  end
end
