class CreateIeoProjects < ActiveRecord::Migration
  def change
    create_table :ieo_projects do |t|
      t.string :name,                     limit: 10,   null: false
      t.string :full_name,                limit: 32,   null: false
      t.string :logo
      t.integer :total_supply,                         null: false
      t.datetime :listing_time
      t.integer :ieo_ceiling
      t.integer :ieo_minimum
      t.string :technological_foundation, limit: 255,  null: false
      t.string :website
      t.string :whitepaper
      t.string :telegram
      t.string :kakao
      t.string :twiter
      t.string :facebook
      t.string :wechat
      t.string :short_describer,          limit: 255,  null: false
      t.string :long_describer,           limit: 255,  null: false
      t.string :introduction,             limit: 255,  null: false
      t.string :tips
      t.integer :member_id

      t.timestamps null: false
    end
  end
end
