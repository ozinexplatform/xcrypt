class CreateNews < ActiveRecord::Migration
  def change
    create_table :news do |t|
      t.string :title,             limit: 128,                                  null: false
      t.text :content,                                                          null: false
      t.string :source,            limit: 1000
      t.integer :views
      t.references :member,                     index: true, foreign_key: true
      t.references :news_category,              index: true, foreign_key: true
      t.timestamps null: false
    end
  end
end
