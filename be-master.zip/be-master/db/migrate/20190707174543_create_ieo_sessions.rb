class CreateIeoSessions < ActiveRecord::Migration
  def change
    create_table :ieo_sessions do |t|
      t.string :currency_id, null: false
      t.integer :status,     null: false, default: 0

      t.timestamps null: false
    end
  end
end
