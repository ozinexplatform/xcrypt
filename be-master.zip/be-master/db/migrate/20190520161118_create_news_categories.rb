class CreateNewsCategories < ActiveRecord::Migration
  def change
    create_table :news_categories do |t|
      t.string :name, null: false, limit: 128, index: true
      t.string :memo,              limit: 255

      t.timestamps null: false
    end
  end
end
