class AddShowBannerToNews < ActiveRecord::Migration
  def change
    add_column :news, :show_banner, :boolean, default: true
  end
end
