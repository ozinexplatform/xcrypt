class CreateIeoRoundSessions < ActiveRecord::Migration
  def change
    create_table :ieo_round_sessions do |t|
      t.integer :ieo_session_id, null: false
      t.integer :ieo_round_id,   null: false
      t.integer :token_amount,   null: false
      t.decimal :session_amount, null: false, precision: 32, scale: 16

      t.timestamps null: false
    end
  end
end
