class AddBonusRegisterFlagToMember < ActiveRecord::Migration
  def change
    add_column :members, :bonus_register_flag, :boolean, default: false
    add_column :members, :bonus_register_at, :datetime
  end
end