# frozen_string_literal: true

class CreateLabels < ActiveRecord::Migration
  def change
    create_table :labels do |t|
      t.references :member
      t.string :key, null: false
      t.string :value, null: false
      t.string :scope, null: false, default: 'public'

      t.timestamps
    end
    add_index :labels, %i[key value member_id], unique: true
    add_foreign_key :labels, :members, on_delete: :cascade
  end
end
