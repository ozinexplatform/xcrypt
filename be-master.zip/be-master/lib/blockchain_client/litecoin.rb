# encoding: UTF-8
# frozen_string_literal: true

module BlockchainClient
  class Litecoin < Bitcoin

  end
end
