# encoding: UTF-8
# frozen_string_literal: true

# Explicitly require "lib/peatio.rb".
# You may be surprised why this line also sits in config/application.rb.
# The same line sits in config/application.rb to allows early access to lib/peatio.rb.
# We duplicate line in config/routes.rb since routes.rb is reloaded when code is changed.
# The implementation of ActiveSupport's require_dependency makes sense to use it only in reloadable files.
# That's why it is here.
require_dependency 'peatio'

Dir['app/models/deposits/**/*.rb'].each { |x| require_dependency x.split('/')[2..-1].join('/') }
Dir['app/models/withdraws/**/*.rb'].each { |x| require_dependency x.split('/')[2..-1].join('/') }

class ActionDispatch::Routing::Mapper
  def draw(routes_name)
    instance_eval(File.read(Rails.root.join("config/routes/#{routes_name}.rb")))
  end
end

Peatio::Application.routes.draw do

  mount Ckeditor::Engine => '/ckeditor'
  root 'welcome#index'

  devise_for :members, :controllers => {
    sessions: 'members/sessions',
    confirmations: 'members/confirmations',
    registrations: 'members/registrations',
    passwords: 'members/passwords'
  }
  match '/members/:id/finish_signup' => 'members#finish_signup', via: [:get, :patch], :as => :finish_signup
  get '/login' => 'sessions#new'
  get '/signout' => 'sessions#destroy'
  get '/signup' => 'register#new'
  get '/auth/failure' => 'sessions#failure'
  match '/auth/:provider/callback' => 'sessions#create', via: %i[get post]

  resources :faq
  resources :chart
  resources :features
  resources :contact
  resources :how_work
  resources :latest_news
  resources :news_details
  resources :support
  resources :support_details
  resources :news, only: %i(index show)
  resources :ieos, only: %i(index show)
  resources :clubs, only: %i(index show)
  resources :airdrops, only: %i(index show)

  scope module: :private do
    resources :login_two_factor, only: [:index, :create]
    # resources :swap_coins, only: %i(index create)

    resources :setting_authens do
      collection do
        get :app_authentication
        get :sms_authentication
        get :security_options
      end
    end

    resources :settings, only: [:index] do
      collection do
        put :update
        patch :update
      end
    end

    get '/verify_account' => 'settings#index'

    get 'profiles' => 'securities#index'
    resources :securities, only: [:index] do
      collection do
        put :update
      end
    end

    resources :sms_authentication do
      collection do
        post :active
        post :deactive
      end
    end

    resources :app_authentication do
      collection do
        post :active
        post :deactive
      end
    end

    resources :otp do
      collection do
        put :update
      end
    end

    resources :withdraw_destinations, only: %i[ create update ]

    resources :funds, only: [:index] do
      collection do
        post :gen_address
      end
    end

    resources 'deposits/:currency', controller: 'deposits', as: 'deposit', only: %i[ destroy ] do
      collection { post 'gen_address' }
    end

    resources 'withdraws/:currency', controller: 'withdraws', as: 'withdraw', only: %i[ create destroy ]

    get '/history/orders' => 'history#orders', as: :order_history
    get '/history/trades' => 'history#trades', as: :trade_history
    get '/history/account' => 'history#account', as: :account_history

    resources :markets, only: [:show], constraints: MarketConstraint do
      resources :orders, only: %i[ index destroy ] do
        collection do
          post :clear
        end
      end
      resources :order_bids, only: [:create] do
        collection do
          post :clear
        end
      end
      resources :order_asks, only: [:create] do
        collection do
          post :clear
        end
      end
    end

    resources :reward_on_refferals
  end

  get 'health/alive', to: 'public/health#alive'
  get 'health/ready', to: 'public/health#ready'

  get 'trading/:market_id', to: BlackHoleRouter.new, as: :trading

  draw :admin

  get '/swagger', to: 'swagger#index'

  mount APIv2::Mount => APIv2::Mount::PREFIX
  mount ManagementAPIv1::Mount => ManagementAPIv1::Mount::PREFIX
end
