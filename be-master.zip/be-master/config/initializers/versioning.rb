# encoding: UTF-8
# frozen_string_literal: true
# This file is auto-generated from the current state of VCS.
# Instead of editing this file, please use bin/gendocs.

module Peatio
  class Application
    GIT_TAG =    '1.9.21'
    GIT_SHA =    '4d83d87'
    BUILD_DATE = 'Fri Mar  8 13:51:36 UTC 2019'
    VERSION =    GIT_TAG
  end
end
